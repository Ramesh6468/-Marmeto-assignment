let resultContainer = document.getElementById("resultSection")
let spinnerEl = document.getElementById("spinner");

spinnerEl.classList.remove("d-none");

resultContainer.textContent = ""


let url = "https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json"
let options = {
    method: "GET"
}
fetch(url, options)
    .then(function(response) {
        return response.json();
    })
    .then(function(jsonData) {
        console.log(jsonData)
        let data = jsonData.categories
        console.log(data)
        if (jsonData !== jsonData.categories) {
            spinnerEl.classList.add("d-none");
            resultContainer.textContent = ""
        }
        const tabContainer = document.getElementById("tabCard")
        const nameCategory = document.getElementById("TabItem");


        data.forEach((category, value) => {
            const tabCard = document.createElement("div")
            tabCard.classList.add("tabItem")
            const tabButton = document.createElement("button")
            tabButton.classList.add("tabButton")
            tabCard.appendChild(tabButton)
            tabButton.textContent = category.category_name

            const content = document.createElement("div");
            content.classList.add("categories-content");

            category.category_products.forEach((product) => {
                console.log(product)
                let productCard = document.createElement("div")
                productCard.classList.add("productCard")
                resultContainer.appendChild(productCard)

                const imageCard = document.createElement("div")
                imageCard.classList.add("imageCard")
                productCard.appendChild(imageCard)
                const imageEl = document.createElement("img")
                imageEl.classList.add("Image2")
                imageEl.src = product.image
                imageEl.alt = "productImage"
                imageCard.appendChild(imageEl)

                const badgeEl = document.createElement("div")
                badgeEl.classList.add("badgeCard")
                badgeEl.textContent = product.badge_text
                imageCard.appendChild(badgeEl)

                const titleCard = document.createElement("div")
                titleCard.classList.add("titleCard")
                productCard.appendChild(titleCard)

                const nameEl = document.createElement("h1")
                nameEl.classList.add("name")
                nameEl.textContent = product.title
                titleCard.appendChild(nameEl)

                const typeEl = document.createElement("h1")
                typeEl.classList.add("type")
                typeEl.textContent = product.vendor
                titleCard.appendChild(typeEl)

                const priceCard = document.createElement("div")
                priceCard.classList.add("priceCard")
                productCard.appendChild(priceCard)

                const priceEl = document.createElement("p")
                priceEl.classList.add("price")
                priceEl.textContent = `Rs ${product.price}.00`
                priceCard.appendChild(priceEl)

                const priceEl2 = document.createElement("p")
                priceEl2.classList.add("price2")
                priceEl2.textContent = `${product.compare_at_price}.00`
                priceCard.appendChild(priceEl2)

                const discountEl = document.createElement("p")
                discountEl.classList.add("discount")
                const discount = ((product.compare_at_price - product.price) / product.compare_at_price) * 100
                discountEl.textContent = `${Math.round(discount)}% Off`
                priceCard.appendChild(discountEl)

                const buttonEl = document.createElement("div")
                buttonEl.classList.add("button")
                buttonEl.textContent = "Add To Cart"
                productCard.appendChild(buttonEl)

                tabCard.addEventListener("click", () => {
                    document.querySelectorAll(".categories-content").forEach((content) => {
                        content.style.display = "none";
                    });

                    content.style.display = "flex";
                    document.querySelectorAll(".categories-tab").forEach((t) => {
                        t.classList.remove("active");
                    });

                    tabCard.classList.add("active");
                });
                tabContainer.appendChild(tabCard)
                nameCategory.appendChild(content);


                if (value === 0) {
                    tabContainer.click();
                }

            })
        })

    });